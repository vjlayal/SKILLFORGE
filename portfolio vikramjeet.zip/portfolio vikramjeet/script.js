const cursor = document.querySelector('.cursor');

document.addEventListener('mousemove', (e) => {
    cursor.style.left = `${e.clientX}px`;
    cursor.style.top = `${e.clientY}px`;
});

document.addEventListener('mousedown', () => {
    cursor.style.backgroundColor = '#3498db';
});

document.addEventListener('mouseup', () => {
    cursor.style.backgroundColor = 'transparent';
});
